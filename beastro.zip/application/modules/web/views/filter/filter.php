<?php
public function get_data()
{
    $ambil_data = $this->db->query(" SELECT * FROM filter ");
    $hasil_ambil_data = $ambil_data->result();
}
?>



<div class="content" style="width: 70%; min-height: 500px;float: right">
	<div style="width:220px;height:280px;float:left;margin:0px;padding-top:13px;padding-bottom:14px">
		<div style="width:200px;height:200px;border:1px solid gray;position:relative;left:9px"><img style="height:200px;width:200px;" src="component/image/hand.jpg"></div>
		<div style="text-align:left;left:10px;top:4px;position:relative;padding-bottom:2px;font-size:20px;line-height:1.5em;color:#222;font-weight:bold;font-style:normal;">Tshirt</div>
		<hr style="width:200px"></hr>
		<div style="text-align:left;left:10px;position:relative;line-height:13px;font-size:12px;font-style:normal;font-weight:400;font-family:Helvetica,Arial,sans-serif;color:#666">0000</div>
		<div style="text-align:left;left:13px;position:relative;font-weight:bold;font-style:normal;font-size:12px;line-height:1.5em;color:#666;cursor:pointer">Rp.1000
		</div>
	</div>

	<div style="width:220px;height:280px;float:left;margin:0px;padding-top:13px;padding-bottom:14px">
		<div style="width:200px;height:200px;border:1px solid gray;position:relative;left:9px"><img style="height:200px;width:200px;" src="component/image/bra.jpg"></div>
		<div style="text-align:left;left:10px;top:4px;position:relative;padding-bottom:2px;font-size:20px;line-height:1.5em;color:#222;font-weight:bold;font-style:normal">Braceleng</div>
		<hr style="width:200px"></hr>
		<div style="text-align:left;left:10px;position:relative;line-height:13px;font-size:12px;font-style:normal;font-weight:400;font-family:Helvetica,Arial,sans-serif;color:#666">Men's Basketball shoe</div>
		<div style="text-align:left;left:13px;position:relative;font-weight:bold;font-style:normal;font-size:12px;line-height:1.5em;color:#666;cursor:pointer">Rp.500
		</div>
	</div>

	<div style="width:220px;height:280px;float:left;margin:0px;padding-top:13px;padding-bottom:14px">
		<div style="width:200px;height:200px;border:1px solid gray;position:relative;left:9px"><img style="height:200px;width:200px;" src="component/image/pants.jpg"></div>
		<div style="text-align:left;left:10px;top:4px;position:relative;padding-bottom:2px;font-size:20px;line-height:1.5em;color:#222;font-weight:bold;font-style:normal;">Pants</div>
		<hr style="width:200px"></hr>
		
		<div style="text-align:left;left:10px;position:relative;line-height:13px;font-size:12px;font-style:normal;font-weight:400;font-family:Helvetica,Arial,sans-serif;color:#666">Men's Basketball shoe</div>
		<div style="text-align:left;left:13px;position:relative;font-weight:bold;font-style:normal;font-size:12px;line-height:1.5em;color:#666;cursor:pointer">Rp.1
		</div>
	</div>

	<div style="width:220px;height:280px;float:left;margin:0px;padding-top:13px;padding-bottom:14px">
		<div style="width:200px;height:200px;border:1px solid gray;position:relative;left:9px"><img style="height:200px;width:200px;" src="component/image/pants.jpg"></div>
		<div style="text-align:left;left:10px;top:4px;position:relative;padding-bottom:2px;font-size:20px;line-height:1.5em;color:#222;font-weight:bold;font-style:normal;">Pants</div>
		<hr style="width:200px"></hr>
		
		<div style="text-align:left;left:10px;position:relative;line-height:13px;font-size:12px;font-style:normal;font-weight:400;font-family:Helvetica,Arial,sans-serif;color:#666">Men's Basketball shoe</div>
		<div style="text-align:left;left:13px;position:relative;font-weight:bold;font-style:normal;font-size:12px;line-height:1.5em;color:#666;cursor:pointer">Rp.1
		</div>
	</div>

	<div style="width:220px;height:280px;float:left;margin:0px;padding-top:13px;padding-bottom:14px">
		<div style="width:200px;height:200px;border:1px solid gray;position:relative;left:9px"><img style="height:200px;width:200px;" src="component/image/pants.jpg"></div>
		<div style="text-align:left;left:10px;top:4px;position:relative;padding-bottom:2px;font-size:20px;line-height:1.5em;color:#222;font-weight:bold;font-style:normal;">Pants</div>
		<hr style="width:200px"></hr>
		
		<div style="text-align:left;left:10px;position:relative;line-height:13px;font-size:12px;font-style:normal;font-weight:400;font-family:Helvetica,Arial,sans-serif;color:#666">Men's Basketball shoe</div>
		<div style="text-align:left;left:13px;position:relative;font-weight:bold;font-style:normal;font-size:12px;line-height:1.5em;color:#666;cursor:pointer">Rp.1
		</div>
	</div>

	<div style="width:220px;height:280px;float:left;margin:0px;padding-top:13px;padding-bottom:14px">
		<div style="width:200px;height:200px;border:1px solid gray;position:relative;left:9px"><img style="height:200px;width:200px;" src="component/image/pants.jpg"></div>
		<div style="text-align:left;left:10px;top:4px;position:relative;padding-bottom:2px;font-size:20px;line-height:1.5em;color:#222;font-weight:bold;font-style:normal;">Pants</div>
		<hr style="width:200px"></hr>
		
		<div style="text-align:left;left:10px;position:relative;line-height:13px;font-size:12px;font-style:normal;font-weight:400;font-family:Helvetica,Arial,sans-serif;color:#666">Men's Basketball shoe</div>
		<div style="text-align:left;left:13px;position:relative;font-weight:bold;font-style:normal;font-size:12px;line-height:1.5em;color:#666;cursor:pointer">Rp.1
		</div>
	</div>

	<div style="width:220px;height:280px;float:left;margin:0px;padding-top:13px;padding-bottom:14px">
		<div style="width:200px;height:200px;border:1px solid gray;position:relative;left:9px"><img style="height:200px;width:200px;" src="component/image/pants.jpg"></div>
		<div style="text-align:left;left:10px;top:4px;position:relative;padding-bottom:2px;font-size:20px;line-height:1.5em;color:#222;font-weight:bold;font-style:normal;">Pants</div>
		<hr style="width:200px"></hr>
		
		<div style="text-align:left;left:10px;position:relative;line-height:13px;font-size:12px;font-style:normal;font-weight:400;font-family:Helvetica,Arial,sans-serif;color:#666">Men's Basketball shoe</div>
		<div style="text-align:left;left:13px;position:relative;font-weight:bold;font-style:normal;font-size:12px;line-height:1.5em;color:#666;cursor:pointer">Rp.1
		</div>
	</div>

	<div style="width:220px;height:280px;float:left;margin:0px;padding-top:13px;padding-bottom:14px">
		<div style="width:200px;height:200px;border:1px solid gray;position:relative;left:9px"><img style="height:200px;width:200px;" src="component/image/pants.jpg"></div>
		<div style="text-align:left;left:10px;top:4px;position:relative;padding-bottom:2px;font-size:20px;line-height:1.5em;color:#222;font-weight:bold;font-style:normal;">Pants</div>
		<hr style="width:200px"></hr>
		
		<div style="text-align:left;left:10px;position:relative;line-height:13px;font-size:12px;font-style:normal;font-weight:400;font-family:Helvetica,Arial,sans-serif;color:#666">Men's Basketball shoe</div>
		<div style="text-align:left;left:13px;position:relative;font-weight:bold;font-style:normal;font-size:12px;line-height:1.5em;color:#666;cursor:pointer">Rp.1
		</div>
	</div>
</div>