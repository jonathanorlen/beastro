<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><a href="#"><img src="<?php echo base_url() . 'component/template/assets/img/ui-sam.jpg'?>" class="img-circle" width="60"></a></p>
              	  <h5 class="centered">ASTRO</h5>
              	  	
                  <li class="mt">
                      <a class="active" href="<?php echo base_url() . 'admin'?>">
                          <i class="fa fa-dashboard"></i>
                          <span>Home</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a  href="<?php echo base_url() . 'admin/about'?>" >
                          <i class="fa fa-desktop"></i>
                          <span>About</span>
                      </a>
                      
                  </li>
                   <li class="sub-menu">
                      <a  href="<?php echo base_url() . 'admin/team'?>">
                          <i class="li_news"></i>
                          <span>Team</span>
                      </a>
                      
                  </li>
                  <li class="sub-menu">
                  <a href="<?php echo base_url() . 'admin/produk'?>">
                          <i class="fa fa-book"></i>
                          <span>Produk</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="<?php echo base_url() . 'admin/inbox'?>" >
                          <i class="fa fa-tasks"></i>
                          <span>Inbox</span>
                      </a>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-th"></i>
                          <span>Data Tables</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="basic_table.html">Basic Table</a></li>
                          <li><a  href="responsive_table.html">Responsive Table</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class=" fa fa-bar-chart-o"></i>
                          <span>Charts</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="morris.html">Morris</a></li>
                          <li><a  href="chartjs.html">Chartjs</a></li>
                      </ul>
                  </li>

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>