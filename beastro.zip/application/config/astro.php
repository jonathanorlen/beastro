<?php
if (!defined("BASEPATH")) exit("No direct script access allowed");
$config["basmalah"] = array (
  'bas_code_dept' => 'N1-003',
  'bas_regency_code' => 'N1',
  'bas_branch_code' => 'N1-003',
  'bas_branch_name' => 'Lawang',
  'bas_branch_address' => 'lawang',
  'bas_branch_phone' => '-',
  'bas_branch_email' => 'asd@asd.com',
  'bas_apps_name' => 'Lawang',
)
?>